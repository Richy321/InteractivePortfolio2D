//----------------------------------//
//	GameMain.cpp					//
//	class for main breakout3D game	//
//	Starts render loop,creates other//
//	objects							//
//	RJ Fox 03/09/2009				//
//----------------------------------//

#include <windows.h>

#include "GameMain.h"

// Link in the DirectX libraries
#pragma comment(lib,"d3d9.lib")
#pragma comment(lib,"dxerr9.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"d3dx9.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"winmm.lib")




//Globals
//HINSTANCE hInst;		//holds the instance for this app
//HWND wndHandle;			//global window handle
/*-----------------------------------------------------------------
						GameMain::GameMain
	Constructor	
	IN:
	OUT:
-------------------------------------------------------------------*/
GameMain::GameMain(void)
{
	Breakout = NULL;
	active = MENU;
	dxManager = new dxMgr();
	inputManager = new dxInputMgr();
	mainMenu = new breakoutMenu();
	soundManager = new dxSoundMgr();
}


/*-----------------------------------------------------------------
						GameMain::~GameMain
	Constructor	
	IN:
	OUT:
-------------------------------------------------------------------*/
GameMain::~GameMain(void)
{
	//delete the dxManager manager
	if( dxManager != NULL) 
	{
        delete dxManager;
		dxManager = NULL;
	}
}

/*-----------------------------------------------------------------
						GameMain::init
		Initialise GameMain object, create/init DX objects
	IN:
	OUT:
-------------------------------------------------------------------*/
bool GameMain::init()
{
	//create new DX Manager
	//dxManager = new dxMgr();
	dxManager->init(m_wndHandle, 800, 600, false);
	if ( !dxManager)
	{
		return false;
	}

	//create new Input Manager
	//inputManager = new dxInputMgr();
	inputManager->init(m_hInstance, m_wndHandle);
	if ( !inputManager)
	{
		return false;
	}

	//create breakoutMenu
	//mainMenu = new breakoutMenu();
	mainMenu->init(inputManager,dxManager->getD3DDevice());
	active = MENU;
	
	//create sound manager
	//soundManager = new dxSoundMgr();
	soundManager->init(m_wndHandle);
	return true;
}

/*-----------------------------------------------------------------
						GameMain::update
		Updates frames, positions, menu and game states.
	IN:
	OUT:
-------------------------------------------------------------------*/
void GameMain::update(void)
{

	//Check for Lost Device
	HRESULT Result = dxManager->getD3DDevice()->TestCooperativeLevel();
	if(FAILED(Result))
	{
		if (Result == D3DERR_DEVICELOST)
		{
			textManager->OnLostDevice();
			return;	//do nothing
		}

		if (Result == D3DERR_DEVICENOTRESET)
		{
			//delete resources
			textManager->OnResetDevice();
			dxManager->getD3DDevice()->Reset(&dxManager->getPresentParameters());
			//init resources
		}
	}
	
	
	//update the menu
	if (active == MENU)
	{
		mainMenu->update();

		if (mainMenu->getMessage() == breakoutMenu::EXIT )
		{
			active = NOTHING;
			delete mainMenu;
			PostQuitMessage(0);
		}

		if ( mainMenu->getMessage() == breakoutMenu::NEW_GAME )
		{	//if an exiting game exists, delete it
			if(Breakout != NULL)
			{
				delete Breakout;
			}
			//Start a new game
			Breakout = new breakout();
			Breakout->init(inputManager, soundManager, dxManager->getD3DDevice());
			active = GAME;
		}
	}


	//game update calls go here
	if(active == GAME)
	{
		Breakout->updateFrames();
		if( Breakout->getMessage() == breakout::QUIT)
		{
			active = NOTHING;
			SAFE_DELETE(Breakout);

			//reactivate the menu
			mainMenu = new breakoutMenu();
			mainMenu->init(inputManager, dxManager->getD3DDevice());
			active = MENU;
		}
	}

	//begin rendering
	dxManager->beginRender();

		if( active == MENU )
		{
			mainMenu->render(dxManager->getD3DDevice());
		}

		if( active == GAME )
		{
			//game render calls here
			Breakout->render(dxManager->getD3DDevice());
		}

	//end render
	dxManager->endRender();

}

/*-----------------------------------------------------------------
						WndProc 
	Standard WndProc callback function.
	Handles window messages.
	IN:
		HWND hWnd,			Handle to Window
		UINT message,		message
		WPARAM wParam,		wParam
		LPARAM lParam		lParam

-------------------------------------------------------------------*/
LRESULT CALLBACK GameMain::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char charPress;
	
	
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
		
		case WM_ACTIVATE:
			if (Breakout != NULL)
			{
				switch (wParam) 
				{
				case WA_ACTIVE:	//1
					{
						Breakout->setWindowActive(true);
						Breakout->resumeGame();
						break;
					}
					
				case WA_CLICKACTIVE:		//2
					{
						Breakout->setWindowActive(true);
						Breakout->resumeGame();
						break;
					}

				case WA_INACTIVE:	//0
					{
						Breakout->setWindowActive(false);
						Breakout->pauseGame();

						break;
					}
				}
			}

		case WM_CHAR: 
            switch (wParam) 
            { 
                case 0x08:
					{
                    // Process a backspace.
					std::string tempName = "";
					tempName = (Breakout->getPlayerName()).substr(0,(Breakout->getPlayerName()).length() -1);
					if (tempName != "")
						Breakout->setPlayerName(tempName);
					else
						Breakout->setPlayerName("Player");
					break; 
					}

                case 0x0A: 
                    // Process a linefeed.  
                    break; 
 
                case 0x1B: 
                    // Process an escape. 
                    break; 
 
                case 0x09: 
                    // Process a tab. 
                    break; 
 
                case 0x0D:                 
                    // Process a carriage return.   
                    break; 
 
                default:
					{
						// Process displayable characters. 
						if (( active == GAME ) && (Breakout->isActive() == false))
						{
							std::string tempName = "";
							charPress = static_cast<int>(wParam);
							tempName = (Breakout->getPlayerName()) + charPress;
							Breakout->setPlayerName(tempName);
						}
					}
                    break; 
            } 
	}
 
	return DefWindowProc(m_wndHandle, message, wParam, lParam);
}


/*
LRESULT CALLBACK GameMain::StaticWndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    if ( msg == WM_CREATE )
    {
        SetWindowLongPtr( hWnd, GWLP_USERDATA, (LONG)(LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams );
    }

    
	GameMain *targetApp = (GameMain*)GetWindowLongPtr( hWnd, GWLP_USERDATA );

    if ( targetApp )
    {
        return targetApp->WndProc( hWnd, msg, wParam, lParam );
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}*/


LRESULT CALLBACK GameMain::StaticWndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	GameMain * pTargetApp = 0;

    if ( msg == WM_NCCREATE )
    {
		pTargetApp = (GameMain*)((LPCREATESTRUCT) lParam)->lpCreateParams;
		SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG)(LONG_PTR)pTargetApp);

		pTargetApp->SetHwnd(hWnd);
    }
	else
		pTargetApp = (GameMain *)(LONG_PTR)GetWindowLongPtr (hWnd, GWLP_USERDATA);

    if (pTargetApp)
    {
        return (pTargetApp->WndProc(hWnd, msg, wParam, lParam ));
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}


bool GameMain::initWindow(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)GameMain::StaticWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= 0;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= "BreakOut3D";
	wcex.hIconSm		= 0;
	RegisterClassEx(&wcex);

	ULONG window_width=800;
    ULONG window_height=600;

	DWORD style=WS_POPUP|WS_VISIBLE;

	style =  WS_OVERLAPPEDWINDOW;

	// Create window and set member var window handle
	m_wndHandle = CreateWindow("BreakOut3D", 
							 "BreakOut3D", 
							 style,
							 0, //CW_USEDEFAULT
							 0, //CW_USEDEFAULT
							 800,
							 600,
							 NULL, 
							 NULL, 
							 hInstance, 
							 this);
	if (!m_wndHandle)
	{

      return false;
	}
 
   // Set the member var instance handle
   m_hInstance = hInstance;

   ShowWindow(m_wndHandle, SW_SHOW);
   UpdateWindow(m_wndHandle);

   return true;
}



/*-----------------------------------------------------------------
						WinMain 
	Calls Init functions, Runs Main Loop.
	Gives control to game whenever it doesn't have messages waiting
	IN:
		HINSTANCE hInstance,		Handle to application
		HINSTANCE hPrevInstance,	Handle to last app(not used)
		LPTSTR lpCmdLine,			
		int nCmdShow
-------------------------------------------------------------------*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{

	// Create the game main
	GameMain *game = new GameMain();	

	//create window using window init function
	if (!game->initWindow(hInstance))
	{
		MessageBox(NULL, "Unable to create window", "Error", MB_OK);
		return false;
	}

	// Initialize the game object
	if (game->init() == false)
	{
		MessageBox(NULL, "Unable to create game object", "Error", MB_OK);
		return false;
	}


	// Main message loop:
	// Enter the message loop
    MSG msg; 
    ZeroMemory( &msg, sizeof(msg) );
    while( msg.message !=WM_QUIT )
    {
		// check for messages
		if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
        {
			TranslateMessage( &msg );
            DispatchMessage( &msg );
        }
		// if there are no messages waiting do this
		else
		{
			game->update();
		}
    }

	// cleanup after message loop
	if (game)
	{
		delete game;
	}

	return (int) msg.wParam;
}

